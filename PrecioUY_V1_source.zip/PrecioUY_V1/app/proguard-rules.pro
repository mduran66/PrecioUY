# V1: sin reglas adicionales.
