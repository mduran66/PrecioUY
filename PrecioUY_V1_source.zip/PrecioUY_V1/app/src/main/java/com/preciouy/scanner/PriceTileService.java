package com.preciouy.scanner;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** Baldosa de Configuración rápida: abre directamente el scanner. */
public class PriceTileService extends TileService {

    @Override
    public void onStartListening() {
        super.onStartListening();
        if (getQsTile() != null) {
            getQsTile().setState(Tile.STATE_ACTIVE);
            getQsTile().setLabel("Precio UY");
            getQsTile().updateTile();
        }
    }

    @Override
    public void onClick() {
        super.onClick();

        Intent intent = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                        Intent.FLAG_ACTIVITY_CLEAR_TOP |
                        Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("launch_source", "tile");

        if (Build.VERSION.SDK_INT >= 34) {
            PendingIntent pendingIntent = PendingIntent.getActivity(
                    this,
                    7001,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            startActivityAndCollapse(pendingIntent);
        } else {
            // API 24-33. TileService es una superficie iniciada por el usuario,
            // por lo que puede lanzar la Activity; MainActivity se muestra sobre lockscreen.
            startActivityAndCollapse(intent);
        }
    }
}
