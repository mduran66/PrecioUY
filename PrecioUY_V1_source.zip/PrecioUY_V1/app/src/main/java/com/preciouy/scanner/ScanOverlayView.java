package com.preciouy.scanner;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/** Marco configurable que coincide con la zona prioritaria del OCR. */
public class ScanOverlayView extends View {
    public static final float MAX_LEFT = 0.07f;
    public static final float MAX_RIGHT = 0.93f;
    public static final float MAX_TOP = 0.25f;
    public static final float MAX_BOTTOM = 0.53f;
    public static final float MIN_SCALE = 0.40f;

    private final Paint dimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cornerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private float widthScale = 1f;
    private float heightScale = 1f;
    private boolean detected = false;

    public ScanOverlayView(Context context) {
        this(context, null);
    }

    public ScanOverlayView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        dimPaint.setColor(0x4F000000);

        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(dp(2f));

        cornerPaint.setStyle(Paint.Style.STROKE);
        cornerPaint.setStrokeWidth(dp(4f));
        cornerPaint.setStrokeCap(Paint.Cap.ROUND);
        applyColors();
    }

    public void setAreaScale(float widthScale, float heightScale) {
        this.widthScale = clamp(widthScale, MIN_SCALE, 1f);
        this.heightScale = clamp(heightScale, MIN_SCALE, 1f);
        invalidate();
    }

    public void setDetected(boolean detected) {
        if (this.detected == detected) return;
        this.detected = detected;
        applyColors();
        invalidate();
    }

    public float getLeftFraction() { return areaFractions().left; }
    public float getRightFraction() { return areaFractions().right; }
    public float getTopFraction() { return areaFractions().top; }
    public float getBottomFraction() { return areaFractions().bottom; }
    public float getCenterYFraction() { return areaFractions().centerY(); }

    private RectF areaFractions() {
        float maxW = MAX_RIGHT - MAX_LEFT;
        float maxH = MAX_BOTTOM - MAX_TOP;
        float centerX = (MAX_LEFT + MAX_RIGHT) / 2f;
        float centerY = (MAX_TOP + MAX_BOTTOM) / 2f;
        float halfW = maxW * widthScale / 2f;
        float halfH = maxH * heightScale / 2f;
        return new RectF(centerX - halfW, centerY - halfH, centerX + halfW, centerY + halfH);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        RectF f = areaFractions();

        float left = w * f.left;
        float right = w * f.right;
        float top = h * f.top;
        float bottom = h * f.bottom;
        RectF r = new RectF(left, top, right, bottom);

        canvas.drawRect(0, 0, w, top, dimPaint);
        canvas.drawRect(0, bottom, w, h, dimPaint);
        canvas.drawRect(0, top, left, bottom, dimPaint);
        canvas.drawRect(right, top, w, bottom, dimPaint);
        canvas.drawRoundRect(r, dp(14), dp(14), borderPaint);

        float c = Math.min(dp(26), Math.min(r.width(), r.height()) * 0.22f);
        canvas.drawLine(left, top + c, left, top, cornerPaint);
        canvas.drawLine(left, top, left + c, top, cornerPaint);
        canvas.drawLine(right - c, top, right, top, cornerPaint);
        canvas.drawLine(right, top, right, top + c, cornerPaint);
        canvas.drawLine(left, bottom - c, left, bottom, cornerPaint);
        canvas.drawLine(left, bottom, left + c, bottom, cornerPaint);
        canvas.drawLine(right - c, bottom, right, bottom, cornerPaint);
        canvas.drawLine(right, bottom - c, right, bottom, cornerPaint);
    }

    private void applyColors() {
        int color = detected ? 0xFF00D084 : 0xCCFFFFFF;
        borderPaint.setColor(color);
        cornerPaint.setColor(color);
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}
