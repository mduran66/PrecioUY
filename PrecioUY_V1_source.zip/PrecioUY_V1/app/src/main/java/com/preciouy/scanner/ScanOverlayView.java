package com.preciouy.scanner;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/**
 * Dibuja una zona de apuntado grande. El OCR analiza la imagen completa y
 * prioriza texto cercano al centro; el marco sirve como guía visual.
 */
public class ScanOverlayView extends View {
    private final Paint dimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cornerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public ScanOverlayView(Context context) {
        this(context, null);
    }

    public ScanOverlayView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        dimPaint.setColor(0x4F000000);

        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(dp(1.5f));
        borderPaint.setColor(0x66FFFFFF);

        cornerPaint.setStyle(Paint.Style.STROKE);
        cornerPaint.setStrokeWidth(dp(4f));
        cornerPaint.setStrokeCap(Paint.Cap.ROUND);
        cornerPaint.setColor(0xFF00D084);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();

        float left = w * 0.07f;
        float right = w * 0.93f;
        float top = h * 0.28f;
        float bottom = h * 0.56f;
        RectF r = new RectF(left, top, right, bottom);

        canvas.drawRect(0, 0, w, top, dimPaint);
        canvas.drawRect(0, bottom, w, h, dimPaint);
        canvas.drawRect(0, top, left, bottom, dimPaint);
        canvas.drawRect(right, top, w, bottom, dimPaint);
        canvas.drawRoundRect(r, dp(14), dp(14), borderPaint);

        float c = dp(26);
        // Esquinas superiores
        canvas.drawLine(left, top + c, left, top, cornerPaint);
        canvas.drawLine(left, top, left + c, top, cornerPaint);
        canvas.drawLine(right - c, top, right, top, cornerPaint);
        canvas.drawLine(right, top, right, top + c, cornerPaint);
        // Esquinas inferiores
        canvas.drawLine(left, bottom - c, left, bottom, cornerPaint);
        canvas.drawLine(left, bottom, left + c, bottom, cornerPaint);
        canvas.drawLine(right - c, bottom, right, bottom, cornerPaint);
        canvas.drawLine(right, bottom - c, right, bottom, cornerPaint);
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}
