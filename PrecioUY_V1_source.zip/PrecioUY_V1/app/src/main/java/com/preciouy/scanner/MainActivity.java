package com.preciouy.scanner;

import android.Manifest;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.app.StatusBarManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Size;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends AppCompatActivity {
    private static final long ANALYSIS_INTERVAL_MS = 240;
    private static final int REQUIRED_STREAK = 2;

    private PreviewView previewView;
    private TextView statusText;
    private TextView arsText;
    private TextView uyuText;
    private TextView rateText;
    private TextView countText;
    private TextView totalText;
    private Button addButton;
    private Button undoButton;

    private PurchaseStore store;
    private TextRecognizer recognizer;
    private ExecutorService cameraExecutor;
    private final AtomicBoolean ocrBusy = new AtomicBoolean(false);
    private long lastAnalysisAt = 0L;

    private double lastCandidate = Double.NaN;
    private int candidateStreak = 0;
    private double stablePriceArs = Double.NaN;

    private final DecimalFormat arsFormat = integerFormat();
    private final DecimalFormat uyuFormat = integerFormat();

    private final ActivityResultLauncher<String> cameraPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    startCamera();
                    maybeOfferTileOnce();
                } else {
                    statusText.setText("Necesito permiso de cámara para escanear precios");
                    addButton.setEnabled(false);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Modo scanner seguro: visible sobre PIN/patrón sin desbloquear el equipo.
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setContentView(R.layout.activity_main);

        previewView = findViewById(R.id.previewView);
        // TextureView evita problemas de z-order con overlays en algunas ROMs Xiaomi.
        previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        statusText = findViewById(R.id.statusText);
        arsText = findViewById(R.id.arsText);
        uyuText = findViewById(R.id.uyuText);
        rateText = findViewById(R.id.rateText);
        countText = findViewById(R.id.countText);
        totalText = findViewById(R.id.totalText);
        addButton = findViewById(R.id.addButton);
        undoButton = findViewById(R.id.undoButton);

        store = new PurchaseStore(this);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        cameraExecutor = Executors.newSingleThreadExecutor();

        findViewById(R.id.settingsButton).setOnClickListener(v -> showSettingsDialog());
        addButton.setOnClickListener(v -> addCurrentPrice());
        undoButton.setOnClickListener(v -> {
            if (store.undo()) {
                v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                refreshPurchaseSummary();
            }
        });
        totalText.setOnLongClickListener(v -> {
            confirmResetPurchase();
            return true;
        });

        refreshRateLabel();
        refreshPurchaseSummary();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
            if (km != null && km.isKeyguardLocked()) {
                statusText.setText("Desbloqueá una vez para dar permiso de cámara");
            }
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        // Reabrir desde baldosa o acceso de cámara debe sentirse instantáneo.
        stablePriceArs = Double.NaN;
        candidateStreak = 0;
        addButton.setEnabled(false);
        statusText.setText(R.string.searching);
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture =
                ProcessCameraProvider.getInstance(this);

        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider provider = cameraProviderFuture.get();

                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                ImageAnalysis analysis = new ImageAnalysis.Builder()
                        .setTargetResolution(new Size(1280, 720))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();

                analysis.setAnalyzer(cameraExecutor, this::analyzeFrame);

                provider.unbindAll();
                provider.bindToLifecycle(
                        this,
                        CameraSelector.DEFAULT_BACK_CAMERA,
                        preview,
                        analysis
                );
            } catch (Exception e) {
                runOnUiThread(() -> statusText.setText("No pude abrir la cámara"));
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void analyzeFrame(@NonNull ImageProxy imageProxy) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastAnalysisAt < ANALYSIS_INTERVAL_MS || !ocrBusy.compareAndSet(false, true)) {
            imageProxy.close();
            return;
        }
        lastAnalysisAt = now;

        if (imageProxy.getImage() == null) {
            ocrBusy.set(false);
            imageProxy.close();
            return;
        }

        int rotation = imageProxy.getImageInfo().getRotationDegrees();
        int sourceW = imageProxy.getWidth();
        int sourceH = imageProxy.getHeight();
        int uprightW = (rotation == 90 || rotation == 270) ? sourceH : sourceW;
        int uprightH = (rotation == 90 || rotation == 270) ? sourceW : sourceH;

        InputImage inputImage = InputImage.fromMediaImage(imageProxy.getImage(), rotation);
        recognizer.process(inputImage)
                .addOnSuccessListener(text -> handleOcrResult(text, uprightW, uprightH))
                .addOnFailureListener(e -> runOnUiThread(() -> statusText.setText(R.string.searching)))
                .addOnCompleteListener(task -> {
                    ocrBusy.set(false);
                    imageProxy.close();
                });
    }

    private void handleOcrResult(Text text, int imageW, int imageH) {
        ScoredCandidate best = null;

        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                Rect box = line.getBoundingBox();
                if (box == null || imageW <= 0 || imageH <= 0) continue;

                float cx = box.exactCenterX() / imageW;
                float cy = box.exactCenterY() / imageH;

                // Zona amplia alrededor del centro. La guía visual es algo más estrecha.
                if (cx < 0.05f || cx > 0.95f || cy < 0.22f || cy > 0.70f) continue;

                PriceParser.ParsedPrice parsed = PriceParser.parse(line.getText());
                if (parsed == null) continue;

                // Cercanía al centro visual + calidad semántica del parser.
                double dist = Math.hypot(cx - 0.5, cy - 0.46);
                int proximity = (int) Math.max(0, 60 - dist * 120);
                int score = parsed.score + proximity;

                ScoredCandidate candidate = new ScoredCandidate(parsed.valueArs, line.getText(), score);
                if (best == null || candidate.score > best.score) best = candidate;
            }
        }

        ScoredCandidate finalBest = best;
        runOnUiThread(() -> updateCandidate(finalBest));
    }

    private void updateCandidate(ScoredCandidate candidate) {
        if (candidate == null) {
            candidateStreak = 0;
            lastCandidate = Double.NaN;
            stablePriceArs = Double.NaN;
            addButton.setEnabled(false);
            statusText.setText(R.string.searching);
            arsText.setText("— ARS");
            uyuText.setText("— UYU");
            return;
        }

        if (!Double.isNaN(lastCandidate) && nearlySame(lastCandidate, candidate.valueArs)) {
            candidateStreak++;
        } else {
            lastCandidate = candidate.valueArs;
            candidateStreak = 1;
            stablePriceArs = Double.NaN;
            addButton.setEnabled(false);
        }

        arsText.setText("$ " + arsFormat.format(candidate.valueArs) + " ARS");
        double uyu = candidate.valueArs * store.getRate();
        uyuText.setText("$ " + uyuFormat.format(uyu) + " UYU");

        if (candidateStreak >= REQUIRED_STREAK) {
            stablePriceArs = candidate.valueArs;
            statusText.setText("Precio detectado ✓");
            addButton.setEnabled(true);
        } else {
            statusText.setText(R.string.confirming);
        }
    }

    private void addCurrentPrice() {
        if (Double.isNaN(stablePriceArs)) return;
        store.add(stablePriceArs);
        addButton.performHapticFeedback(
                Build.VERSION.SDK_INT >= 30 ? HapticFeedbackConstants.CONFIRM : HapticFeedbackConstants.KEYBOARD_TAP
        );
        Toast.makeText(this, "Agregado", Toast.LENGTH_SHORT).show();
        refreshPurchaseSummary();
    }

    private void refreshRateLabel() {
        rateText.setText("1 ARS = " + formatRate(store.getRate()) + " UYU");
    }

    private void refreshPurchaseSummary() {
        int count = store.getCount();
        double totalArs = store.getTotalArs();
        double totalUyu = totalArs * store.getRate();
        countText.setText(count == 1 ? "1 producto" : count + " productos");
        totalText.setText("$ " + uyuFormat.format(totalUyu) + " UYU");
        undoButton.setEnabled(count > 0);
        undoButton.setAlpha(count > 0 ? 1f : 0.35f);
    }

    private void showSettingsDialog() {
        float currentRate = store.getRate();

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        container.setPadding(pad, dp(8), pad, 0);

        TextView help = new TextView(this);
        help.setText("Tipo de cambio manual de esta V1. Ejemplo: 0,0267 significa que 1 ARS = 0,0267 UYU.");
        help.setTextSize(14);
        container.addView(help);

        EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER |
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setSingleLine(true);
        input.setText(formatRate(currentRate));
        input.setSelectAllOnFocus(true);
        container.addView(input, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        Button newPurchase = new Button(this);
        newPurchase.setText("Nueva compra");
        newPurchase.setAllCaps(false);
        newPurchase.setOnClickListener(v -> confirmResetPurchase());
        container.addView(newPurchase, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Ajustes")
                .setView(container)
                .setPositiveButton("Guardar cambio", null)
                .setNeutralButton("Baldosa", null)
                .setNegativeButton("Cerrar", null)
                .create();

        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String raw = input.getText().toString().trim().replace(',', '.');
                try {
                    float rate = Float.parseFloat(raw);
                    if (rate <= 0 || rate > 10) throw new NumberFormatException();
                    store.setRate(rate);
                    refreshRateLabel();
                    refreshPurchaseSummary();
                    if (!Double.isNaN(stablePriceArs)) {
                        uyuText.setText("$ " + uyuFormat.format(stablePriceArs * rate) + " UYU");
                    }
                    Toast.makeText(this, "Tipo de cambio guardado", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                } catch (NumberFormatException e) {
                    input.setError("Ingresá un número válido, por ejemplo 0,0267");
                }
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> requestQuickTile());
        });

        dialog.setOnDismissListener(d -> hideKeyboard(input));
        dialog.show();
    }

    private void confirmResetPurchase() {
        new AlertDialog.Builder(this)
                .setTitle("¿Nueva compra?")
                .setMessage("Borra el total y los productos agregados de la compra actual.")
                .setPositiveButton("Nueva compra", (d, w) -> {
                    store.reset();
                    refreshPurchaseSummary();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void maybeOfferTileOnce() {
        if (Build.VERSION.SDK_INT < 33) return;
        android.content.SharedPreferences prefs = getSharedPreferences("precio_uy_setup", MODE_PRIVATE);
        if (prefs.getBoolean("tile_offered", false)) return;
        prefs.edit().putBoolean("tile_offered", true).apply();

        // No interrumpimos el primer frame: damos un momento a la cámara y luego
        // usamos el prompt oficial del sistema para añadir la baldosa.
        previewView.postDelayed(this::requestQuickTile, 900);
    }

    private void requestQuickTile() {
        if (Build.VERSION.SDK_INT >= 33) {
            StatusBarManager manager = getSystemService(StatusBarManager.class);
            if (manager == null) {
                Toast.makeText(this, "Abrí el Centro de control y agregá “Precio UY” manualmente", Toast.LENGTH_LONG).show();
                return;
            }
            manager.requestAddTileService(
                    new ComponentName(this, PriceTileService.class),
                    "Precio UY",
                    Icon.createWithResource(this, R.drawable.ic_tile),
                    ContextCompat.getMainExecutor(this),
                    result -> {
                        if (result == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED ||
                                result == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ALREADY_ADDED) {
                            Toast.makeText(this, "Baldosa lista", Toast.LENGTH_SHORT).show();
                        } else if (result == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_NOT_ADDED) {
                            Toast.makeText(this, "No se agregó. También podés hacerlo desde Editar en el Centro de control.", Toast.LENGTH_LONG).show();
                        }
                    }
            );
        } else {
            Toast.makeText(this,
                    "Bajá el panel rápido → Editar → buscá “Precio UY” y arrastrala a tus accesos.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void hideKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private static boolean nearlySame(double a, double b) {
        return Math.abs(a - b) <= Math.max(0.01, Math.abs(a) * 0.001);
    }

    private static DecimalFormat integerFormat() {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(new Locale("es", "AR"));
        symbols.setGroupingSeparator('.');
        symbols.setDecimalSeparator(',');
        DecimalFormat format = new DecimalFormat("#,##0", symbols);
        format.setGroupingUsed(true);
        format.setMaximumFractionDigits(0);
        return format;
    }

    private static String formatRate(float rate) {
        return String.format(Locale.US, "%.4f", rate).replace('.', ',');
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (recognizer != null) recognizer.close();
        if (cameraExecutor != null) cameraExecutor.shutdown();
    }

    private static final class ScoredCandidate {
        final double valueArs;
        final String raw;
        final int score;

        ScoredCandidate(double valueArs, String raw, int score) {
            this.valueArs = valueArs;
            this.raw = raw;
            this.score = score;
        }
    }
}
