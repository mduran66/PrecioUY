package com.preciouy.scanner;

import android.Manifest;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.app.StatusBarManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Size;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends AppCompatActivity {
    private static final long ANALYSIS_INTERVAL_MS = 240;
    private static final int REQUIRED_STREAK = 2;

    private PreviewView previewView;
    private ScanOverlayView scanOverlay;
    private TextView statusText;
    private TextView arsText;
    private TextView uyuText;
    private TextView rateText;
    private TextView countText;
    private TextView totalText;
    private Button addButton;
    private Button undoButton;
    private Button emptyCartButton;

    private PurchaseStore store;
    private TextRecognizer recognizer;
    private ExecutorService cameraExecutor;
    private final AtomicBoolean ocrBusy = new AtomicBoolean(false);
    private long lastAnalysisAt = 0L;

    private ScoredCandidate currentCandidate;
    private int candidateStreak = 0;
    private boolean alternateSelected = false;
    private double stablePriceArs = Double.NaN;

    private final DecimalFormat integerFormat = integerFormat();
    private final DecimalFormat centsFormat = centsFormat();

    private final ActivityResultLauncher<String> cameraPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    startCamera();
                    maybeOfferTileOnce();
                } else {
                    statusText.setText("Necesito permiso de cámara para escanear precios");
                    addButton.setEnabled(false);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setContentView(R.layout.activity_main);

        previewView = findViewById(R.id.previewView);
        previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        scanOverlay = findViewById(R.id.scanOverlay);
        statusText = findViewById(R.id.statusText);
        arsText = findViewById(R.id.arsText);
        uyuText = findViewById(R.id.uyuText);
        rateText = findViewById(R.id.rateText);
        countText = findViewById(R.id.countText);
        totalText = findViewById(R.id.totalText);
        addButton = findViewById(R.id.addButton);
        undoButton = findViewById(R.id.undoButton);
        emptyCartButton = findViewById(R.id.emptyCartButton);

        store = new PurchaseStore(this);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        cameraExecutor = Executors.newSingleThreadExecutor();

        scanOverlay.setAreaScale(store.getScanWidthScale(), store.getScanHeightScale());

        findViewById(R.id.settingsButton).setOnClickListener(v -> showSettingsDialog());
        addButton.setOnClickListener(v -> addCurrentPrice());
        arsText.setOnClickListener(v -> toggleAlternative());
        undoButton.setOnClickListener(v -> undoLastAdd());
        emptyCartButton.setOnClickListener(v -> confirmEmptyCart());

        refreshRateLabel();
        refreshPurchaseSummary();
        clearCandidateUi();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
            if (km != null && km.isKeyguardLocked()) {
                statusText.setText("Desbloqueá una vez para dar permiso de cámara");
            }
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        resetCandidateState();
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture =
                ProcessCameraProvider.getInstance(this);

        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider provider = cameraProviderFuture.get();

                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                ImageAnalysis analysis = new ImageAnalysis.Builder()
                        .setTargetResolution(new Size(1280, 720))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();

                analysis.setAnalyzer(cameraExecutor, this::analyzeFrame);

                provider.unbindAll();
                provider.bindToLifecycle(
                        this,
                        CameraSelector.DEFAULT_BACK_CAMERA,
                        preview,
                        analysis
                );
            } catch (Exception e) {
                runOnUiThread(() -> statusText.setText("No pude abrir la cámara"));
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void analyzeFrame(@NonNull ImageProxy imageProxy) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastAnalysisAt < ANALYSIS_INTERVAL_MS || !ocrBusy.compareAndSet(false, true)) {
            imageProxy.close();
            return;
        }
        lastAnalysisAt = now;

        if (imageProxy.getImage() == null) {
            ocrBusy.set(false);
            imageProxy.close();
            return;
        }

        int rotation = imageProxy.getImageInfo().getRotationDegrees();
        int sourceW = imageProxy.getWidth();
        int sourceH = imageProxy.getHeight();
        int uprightW = (rotation == 90 || rotation == 270) ? sourceH : sourceW;
        int uprightH = (rotation == 90 || rotation == 270) ? sourceW : sourceH;

        InputImage inputImage = InputImage.fromMediaImage(imageProxy.getImage(), rotation);
        recognizer.process(inputImage)
                .addOnSuccessListener(text -> handleOcrResult(text, uprightW, uprightH))
                .addOnFailureListener(e -> runOnUiThread(this::resetCandidateState))
                .addOnCompleteListener(task -> {
                    ocrBusy.set(false);
                    imageProxy.close();
                });
    }

    private void handleOcrResult(Text text, int imageW, int imageH) {
        ScoredCandidate best = null;

        float left = scanOverlay.getLeftFraction();
        float right = scanOverlay.getRightFraction();
        float top = scanOverlay.getTopFraction();
        float bottom = scanOverlay.getBottomFraction();
        float centerX = (left + right) / 2f;
        float centerY = (top + bottom) / 2f;
        float roiW = Math.max(0.01f, right - left);
        float roiH = Math.max(0.01f, bottom - top);

        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                Rect box = line.getBoundingBox();
                if (box == null || imageW <= 0 || imageH <= 0) continue;

                float cx = box.exactCenterX() / imageW;
                float cy = box.exactCenterY() / imageH;
                if (cx < left || cx > right || cy < top || cy > bottom) continue;

                PriceParser.ParsedPrice parsed = PriceParser.parse(line.getText());
                if (parsed == null) continue;

                double nx = (cx - centerX) / roiW;
                double ny = (cy - centerY) / roiH;
                double dist = Math.hypot(nx, ny);
                int proximity = (int) Math.max(0, 60 - dist * 80);
                int score = parsed.score + proximity;

                ScoredCandidate candidate = new ScoredCandidate(
                        parsed.valueArs,
                        parsed.alternateValueArs,
                        line.getText(),
                        parsed.token,
                        score
                );
                if (best == null || candidate.score > best.score) best = candidate;
            }
        }

        ScoredCandidate finalBest = best;
        runOnUiThread(() -> updateCandidate(finalBest));
    }

    private void updateCandidate(ScoredCandidate candidate) {
        if (candidate == null) {
            resetCandidateState();
            return;
        }

        if (sameCandidate(currentCandidate, candidate)) {
            candidateStreak++;
        } else {
            currentCandidate = candidate;
            candidateStreak = 1;
            alternateSelected = false;
            stablePriceArs = Double.NaN;
        }
        currentCandidate = candidate;

        displayCurrentCandidate();

        if (candidateStreak >= REQUIRED_STREAK) {
            stablePriceArs = selectedCandidateValue();
            scanOverlay.setDetected(true);
            addButton.setEnabled(true);
            if (currentCandidate.alternateValueArs != null) {
                statusText.setText("Precio detectado ✓ · tocá 🇦🇷 para alternativa");
            } else {
                statusText.setText("Precio detectado ✓");
            }
        } else {
            stablePriceArs = Double.NaN;
            scanOverlay.setDetected(false);
            addButton.setEnabled(false);
            statusText.setText(R.string.confirming);
        }
    }

    private void displayCurrentCandidate() {
        if (currentCandidate == null) {
            clearCandidateUi();
            return;
        }
        double ars = selectedCandidateValue();
        arsText.setText("🇦🇷 $ " + formatArs(ars) + " ARS");
        uyuText.setText("🇺🇾 $ " + integerFormat.format(ars * store.getRate()) + " UYU");
    }

    private void toggleAlternative() {
        if (currentCandidate == null || currentCandidate.alternateValueArs == null) return;
        alternateSelected = !alternateSelected;
        arsText.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        displayCurrentCandidate();
        if (candidateStreak >= REQUIRED_STREAK) stablePriceArs = selectedCandidateValue();
        statusText.setText(alternateSelected
                ? "Alternativa seleccionada · tocá 🇦🇷 para volver"
                : "Precio detectado ✓ · tocá 🇦🇷 para alternativa");
    }

    private double selectedCandidateValue() {
        if (currentCandidate == null) return Double.NaN;
        if (alternateSelected && currentCandidate.alternateValueArs != null) {
            return currentCandidate.alternateValueArs;
        }
        return currentCandidate.valueArs;
    }

    private void clearCandidateUi() {
        arsText.setText("🇦🇷 — ARS");
        uyuText.setText("🇺🇾 — UYU");
        statusText.setText(R.string.searching);
        scanOverlay.setDetected(false);
        addButton.setEnabled(false);
    }

    private void resetCandidateState() {
        currentCandidate = null;
        candidateStreak = 0;
        alternateSelected = false;
        stablePriceArs = Double.NaN;
        clearCandidateUi();
    }

    private void addCurrentPrice() {
        if (Double.isNaN(stablePriceArs)) return;
        store.add(stablePriceArs);
        addButton.performHapticFeedback(
                Build.VERSION.SDK_INT >= 30 ? HapticFeedbackConstants.CONFIRM : HapticFeedbackConstants.KEYBOARD_TAP
        );
        Toast.makeText(this, "Agregado al carrito", Toast.LENGTH_SHORT).show();
        refreshPurchaseSummary();
    }

    private void undoLastAdd() {
        if (store.undo()) {
            undoButton.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
            refreshPurchaseSummary();
            Toast.makeText(this, "Último agregado deshecho", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshRateLabel() {
        rateText.setText("1 ARS = " + formatRate(store.getRate()) + " UYU");
    }

    private void refreshPurchaseSummary() {
        int count = store.getCount();
        double totalUyu = store.getTotalArs() * store.getRate();
        countText.setText(count == 1 ? "1 producto" : count + " productos");
        totalText.setText("🇺🇾 $ " + integerFormat.format(totalUyu) + " UYU");

        boolean canUndo = store.isUndoAvailable();
        undoButton.setEnabled(canUndo);
        undoButton.setAlpha(canUndo ? 1f : 0.30f);

        boolean hasItems = count > 0;
        emptyCartButton.setEnabled(hasItems);
        emptyCartButton.setAlpha(hasItems ? 1f : 0.30f);
    }

    private void showSettingsDialog() {
        float currentRate = store.getRate();
        int currentWidth = Math.round(store.getScanWidthScale() * 100);
        int currentHeight = Math.round(store.getScanHeightScale() * 100);

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        container.setPadding(pad, dp(8), pad, 0);

        TextView rateHelp = new TextView(this);
        rateHelp.setText("Tipo de cambio manual. Ej.: 0,0267 significa que 1 ARS = 0,0267 UYU.");
        rateHelp.setTextSize(14);
        container.addView(rateHelp);

        EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER |
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setSingleLine(true);
        input.setText(formatRate(currentRate));
        input.setSelectAllOnFocus(true);
        container.addView(input, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView areaTitle = new TextView(this);
        areaTitle.setText("Área de escaneo");
        areaTitle.setTextSize(16);
        areaTitle.setPadding(0, dp(16), 0, dp(4));
        container.addView(areaTitle);

        TextView widthLabel = new TextView(this);
        widthLabel.setText("Ancho: " + currentWidth + "%");
        container.addView(widthLabel);

        SeekBar widthSeek = new SeekBar(this);
        widthSeek.setMin(40);
        widthSeek.setMax(100);
        widthSeek.setProgress(currentWidth);
        container.addView(widthSeek);

        TextView heightLabel = new TextView(this);
        heightLabel.setText("Alto: " + currentHeight + "%");
        container.addView(heightLabel);

        SeekBar heightSeek = new SeekBar(this);
        heightSeek.setMin(40);
        heightSeek.setMax(100);
        heightSeek.setProgress(currentHeight);
        container.addView(heightSeek);

        widthSeek.setOnSeekBarChangeListener(simpleSeekListener(progress ->
                widthLabel.setText("Ancho: " + progress + "%")));
        heightSeek.setOnSeekBarChangeListener(simpleSeekListener(progress ->
                heightLabel.setText("Alto: " + progress + "%")));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Ajustes")
                .setView(container)
                .setPositiveButton("Guardar", null)
                .setNeutralButton("Baldosa", null)
                .setNegativeButton("Cerrar", null)
                .create();

        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String raw = input.getText().toString().trim().replace(',', '.');
                try {
                    float rate = Float.parseFloat(raw);
                    if (rate <= 0 || rate > 10) throw new NumberFormatException();

                    float widthScale = widthSeek.getProgress() / 100f;
                    float heightScale = heightSeek.getProgress() / 100f;
                    store.setRate(rate);
                    store.setScanArea(widthScale, heightScale);
                    scanOverlay.setAreaScale(widthScale, heightScale);

                    refreshRateLabel();
                    refreshPurchaseSummary();
                    if (currentCandidate != null) displayCurrentCandidate();
                    resetCandidateState();
                    Toast.makeText(this, "Ajustes guardados", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                } catch (NumberFormatException e) {
                    input.setError("Ingresá un número válido, por ejemplo 0,0267");
                }
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> requestQuickTile());
        });

        dialog.setOnDismissListener(d -> hideKeyboard(input));
        dialog.show();
    }

    private SeekBar.OnSeekBarChangeListener simpleSeekListener(IntConsumer consumer) {
        return new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                consumer.accept(progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        };
    }

    private void confirmEmptyCart() {
        new AlertDialog.Builder(this)
                .setTitle("¿Vaciar carrito?")
                .setMessage("Se borran todos los productos y el total de la compra actual.")
                .setPositiveButton("Vaciar", (d, w) -> {
                    store.reset();
                    refreshPurchaseSummary();
                    Toast.makeText(this, "Carrito vacío", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void maybeOfferTileOnce() {
        if (Build.VERSION.SDK_INT < 33) return;
        android.content.SharedPreferences prefs = getSharedPreferences("precio_uy_setup", MODE_PRIVATE);
        if (prefs.getBoolean("tile_offered", false)) return;
        prefs.edit().putBoolean("tile_offered", true).apply();
        previewView.postDelayed(this::requestQuickTile, 900);
    }

    private void requestQuickTile() {
        if (Build.VERSION.SDK_INT >= 33) {
            StatusBarManager manager = getSystemService(StatusBarManager.class);
            if (manager == null) {
                Toast.makeText(this, "Abrí el Centro de control y agregá “Precio UY” manualmente", Toast.LENGTH_LONG).show();
                return;
            }
            manager.requestAddTileService(
                    new ComponentName(this, PriceTileService.class),
                    "Precio UY",
                    Icon.createWithResource(this, R.drawable.ic_tile),
                    ContextCompat.getMainExecutor(this),
                    result -> {
                        if (result == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED ||
                                result == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ALREADY_ADDED) {
                            Toast.makeText(this, "Baldosa lista", Toast.LENGTH_SHORT).show();
                        } else if (result == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_NOT_ADDED) {
                            Toast.makeText(this, "No se agregó. También podés hacerlo desde Editar en el Centro de control.", Toast.LENGTH_LONG).show();
                        }
                    }
            );
        } else {
            Toast.makeText(this,
                    "Bajá el panel rápido → Editar → buscá “Precio UY” y arrastrala a tus accesos.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void hideKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private static boolean sameCandidate(ScoredCandidate a, ScoredCandidate b) {
        if (a == null || b == null) return false;
        if (!nearlySame(a.valueArs, b.valueArs)) return false;
        if (a.alternateValueArs == null && b.alternateValueArs == null) return true;
        if (a.alternateValueArs == null || b.alternateValueArs == null) return false;
        return nearlySame(a.alternateValueArs, b.alternateValueArs);
    }

    private static boolean nearlySame(double a, double b) {
        return Math.abs(a - b) <= Math.max(0.01, Math.abs(a) * 0.001);
    }

    private String formatArs(double value) {
        if (Math.abs(value - Math.rint(value)) < 0.005) return integerFormat.format(value);
        return centsFormat.format(value);
    }

    private static DecimalFormat integerFormat() {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(new Locale("es", "AR"));
        symbols.setGroupingSeparator('.');
        symbols.setDecimalSeparator(',');
        DecimalFormat format = new DecimalFormat("#,##0", symbols);
        format.setGroupingUsed(true);
        format.setMaximumFractionDigits(0);
        return format;
    }

    private static DecimalFormat centsFormat() {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(new Locale("es", "AR"));
        symbols.setGroupingSeparator('.');
        symbols.setDecimalSeparator(',');
        DecimalFormat format = new DecimalFormat("#,##0.00", symbols);
        format.setGroupingUsed(true);
        format.setMinimumFractionDigits(2);
        format.setMaximumFractionDigits(2);
        return format;
    }

    private static String formatRate(float rate) {
        return String.format(Locale.US, "%.4f", rate).replace('.', ',');
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (recognizer != null) recognizer.close();
        if (cameraExecutor != null) cameraExecutor.shutdown();
    }

    private interface IntConsumer {
        void accept(int value);
    }

    private static final class ScoredCandidate {
        final double valueArs;
        final Double alternateValueArs;
        final String raw;
        final String token;
        final int score;

        ScoredCandidate(double valueArs, Double alternateValueArs, String raw, String token, int score) {
            this.valueArs = valueArs;
            this.alternateValueArs = alternateValueArs;
            this.raw = raw;
            this.token = token;
            this.score = score;
        }
    }
}
