package com.preciouy.scanner;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/** Persistencia local de la compra, el tipo de cambio y preferencias simples. */
public final class PurchaseStore {
    private static final String PREFS = "precio_uy_prefs";
    private static final String KEY_ITEMS = "items_ars";
    private static final String KEY_RATE = "ars_to_uyu_rate";
    private static final String KEY_UNDO_AVAILABLE = "undo_available";
    private static final String KEY_SCAN_WIDTH = "scan_width";
    private static final String KEY_SCAN_HEIGHT = "scan_height";

    public static final float DEFAULT_RATE = 0.0267f;

    private final SharedPreferences prefs;

    public PurchaseStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public List<Double> getItems() {
        String raw = prefs.getString(KEY_ITEMS, "[]");
        ArrayList<Double> out = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) out.add(array.getDouble(i));
        } catch (JSONException ignored) {
            prefs.edit().putString(KEY_ITEMS, "[]").apply();
        }
        return out;
    }

    public void add(double valueArs) {
        List<Double> items = getItems();
        items.add(valueArs);
        saveItems(items);
        prefs.edit().putBoolean(KEY_UNDO_AVAILABLE, true).apply();
    }

    /** Solo permite deshacer una vez después de la última inclusión. */
    public boolean undo() {
        if (!isUndoAvailable()) return false;
        List<Double> items = getItems();
        if (items.isEmpty()) {
            prefs.edit().putBoolean(KEY_UNDO_AVAILABLE, false).apply();
            return false;
        }
        items.remove(items.size() - 1);
        saveItems(items);
        prefs.edit().putBoolean(KEY_UNDO_AVAILABLE, false).apply();
        return true;
    }

    public boolean isUndoAvailable() {
        return prefs.getBoolean(KEY_UNDO_AVAILABLE, false) && !getItems().isEmpty();
    }

    public void reset() {
        prefs.edit()
                .putString(KEY_ITEMS, "[]")
                .putBoolean(KEY_UNDO_AVAILABLE, false)
                .apply();
    }

    public double getTotalArs() {
        double total = 0;
        for (Double v : getItems()) total += v;
        return total;
    }

    public int getCount() {
        return getItems().size();
    }

    public float getRate() {
        return prefs.getFloat(KEY_RATE, DEFAULT_RATE);
    }

    public void setRate(float rate) {
        prefs.edit().putFloat(KEY_RATE, rate).apply();
    }

    public float getScanWidthScale() {
        return clamp(prefs.getFloat(KEY_SCAN_WIDTH, 1f));
    }

    public float getScanHeightScale() {
        return clamp(prefs.getFloat(KEY_SCAN_HEIGHT, 1f));
    }

    public void setScanArea(float widthScale, float heightScale) {
        prefs.edit()
                .putFloat(KEY_SCAN_WIDTH, clamp(widthScale))
                .putFloat(KEY_SCAN_HEIGHT, clamp(heightScale))
                .apply();
    }

    private static float clamp(float value) {
        return Math.max(ScanOverlayView.MIN_SCALE, Math.min(1f, value));
    }

    private void saveItems(List<Double> items) {
        JSONArray array = new JSONArray();
        for (Double v : items) array.put(v);
        prefs.edit().putString(KEY_ITEMS, array.toString()).apply();
    }
}
