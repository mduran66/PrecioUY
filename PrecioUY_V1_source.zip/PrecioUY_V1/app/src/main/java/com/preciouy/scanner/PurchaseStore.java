package com.preciouy.scanner;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/** Persistencia local mínima de la compra actual y el tipo de cambio. */
public final class PurchaseStore {
    private static final String PREFS = "precio_uy_prefs";
    private static final String KEY_ITEMS = "items_ars";
    private static final String KEY_RATE = "ars_to_uyu_rate";

    // Referencia inicial de V1. Es editable; no se actualiza automáticamente.
    public static final float DEFAULT_RATE = 0.0267f;

    private final SharedPreferences prefs;

    public PurchaseStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public List<Double> getItems() {
        String raw = prefs.getString(KEY_ITEMS, "[]");
        ArrayList<Double> out = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) out.add(array.getDouble(i));
        } catch (JSONException ignored) {
            prefs.edit().putString(KEY_ITEMS, "[]").apply();
        }
        return out;
    }

    public void add(double valueArs) {
        List<Double> items = getItems();
        items.add(valueArs);
        saveItems(items);
    }

    public boolean undo() {
        List<Double> items = getItems();
        if (items.isEmpty()) return false;
        items.remove(items.size() - 1);
        saveItems(items);
        return true;
    }

    public void reset() {
        prefs.edit().putString(KEY_ITEMS, "[]").apply();
    }

    public double getTotalArs() {
        double total = 0;
        for (Double v : getItems()) total += v;
        return total;
    }

    public int getCount() {
        return getItems().size();
    }

    public float getRate() {
        return prefs.getFloat(KEY_RATE, DEFAULT_RATE);
    }

    public void setRate(float rate) {
        prefs.edit().putFloat(KEY_RATE, rate).apply();
    }

    private void saveItems(List<Double> items) {
        JSONArray array = new JSONArray();
        for (Double v : items) array.put(v);
        prefs.edit().putString(KEY_ITEMS, array.toString()).apply();
    }
}
