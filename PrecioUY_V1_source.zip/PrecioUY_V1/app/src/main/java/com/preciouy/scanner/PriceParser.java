package com.preciouy.scanner;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Lógica aislada para convertir texto OCR en un posible precio argentino. */
public final class PriceParser {
    private PriceParser() {}

    // Captura precios con dígitos y separadores habituales. La interpretación
    // se hace después con reglas argentinas, no con formato estadounidense.
    private static final Pattern NUMBER = Pattern.compile(
            "(?<!\\d)([0-9]{1,7}(?:[.,\\s][0-9]{1,3}){0,3})(?!\\d)"
    );

    public static ParsedPrice parse(String raw) {
        if (raw == null) return null;
        String text = raw.trim();
        if (text.isEmpty()) return null;

        String lower = text.toLowerCase(Locale.ROOT);
        boolean hasCurrency = text.contains("$") || lower.contains("ars") || lower.contains("ar$");

        if (!hasCurrency) {
            if (text.contains("%") ||
                    lower.matches(".*\\b(kg|gr|g|mg|ml|cc|lts?|litros?|unid(?:ad)?es?)\\b.*")) {
                return null;
            }
        }

        Matcher matcher = NUMBER.matcher(text);
        ParsedPrice best = null;
        while (matcher.find()) {
            String token = matcher.group(1).trim();
            Interpretation interpretation = interpretArgentine(token);
            if (interpretation == null || interpretation.primary <= 0 || interpretation.primary > 9_999_999) {
                continue;
            }

            String digitsOnly = token.replaceAll("\\D", "");
            if (!hasCurrency && digitsOnly.length() >= 8) continue;

            int score = 0;
            if (hasCurrency) score += 100;
            if (token.contains(".") || token.contains(",") || token.contains(" ")) score += 12;
            if (interpretation.followsArgentineRules) score += 25;
            if (interpretation.alternate != null) score -= 4;
            if (interpretation.primary >= 100) score += 5;

            ParsedPrice candidate = new ParsedPrice(
                    interpretation.primary,
                    interpretation.alternate,
                    raw,
                    token,
                    score,
                    interpretation.followsArgentineRules
            );
            if (best == null || candidate.score > best.score) best = candidate;
        }
        return best;
    }

    /**
     * Reglas principales:
     * - punto = miles y cada grupo posterior debe tener exactamente 3 dígitos;
     * - coma = centavos y debe tener exactamente 2 dígitos;
     * - si OCR rompe esas reglas, devuelve una interpretación principal y,
     *   cuando tiene sentido, una alternativa de un toque.
     */
    static Interpretation interpretArgentine(String token) {
        if (token == null) return null;
        String s = token.replace(" ", "").trim();
        if (s.isEmpty() || !s.matches("[0-9.,]+")) return null;

        try {
            int dotCount = countChar(s, '.');
            int commaCount = countChar(s, ',');

            if (dotCount == 0 && commaCount == 0) {
                return new Interpretation(Double.parseDouble(s), null, true);
            }

            // Formato argentino completo: 1.234.567,89
            if (commaCount == 1 && s.indexOf(',') > 0) {
                int commaPos = s.indexOf(',');
                String integerPart = s.substring(0, commaPos);
                String cents = s.substring(commaPos + 1);
                boolean centsValid = cents.matches("\\d{2}");
                boolean integerValid = validThousands(integerPart);

                if (centsValid && integerValid) {
                    double value = Double.parseDouble(integerPart.replace(".", "") + "." + cents);
                    return new Interpretation(value, null, true);
                }

                // OCR pudo haber confundido un punto de miles con una coma.
                // Ej.: 12,500 -> 12500.
                if (dotCount == 0 && cents.matches("\\d{3}")) {
                    double value = Double.parseDouble(s.replace(",", ""));
                    return new Interpretation(value, null, false);
                }

                // Coma con 1 dígito no cumple la regla de 2 centavos. La
                // mostramos como decimal, pero permitimos quitar el separador.
                if (dotCount == 0 && cents.matches("\\d{1}")) {
                    double decimal = Double.parseDouble(s.replace(',', '.'));
                    double joined = Double.parseDouble(s.replace(",", ""));
                    return new Interpretation(decimal, distinct(decimal, joined), false);
                }
            }

            // Solo puntos.
            if (commaCount == 0 && dotCount > 0) {
                if (validThousands(s)) {
                    return new Interpretation(Double.parseDouble(s.replace(".", "")), null, true);
                }

                if (dotCount == 1) {
                    int pos = s.indexOf('.');
                    String head = s.substring(0, pos);
                    String tail = s.substring(pos + 1);
                    if (head.matches("\\d+") && tail.matches("\\d{1,2}")) {
                        // Ej. OCR: 12.50. En Argentina el punto no puede ser
                        // decimal. Asumimos primero que confundió ',' con '.',
                        // y con un toque se puede interpretar 1250.
                        double decimal = Double.parseDouble(head + "." + tail);
                        double joined = Double.parseDouble(head + tail);
                        return new Interpretation(decimal, distinct(decimal, joined), false);
                    }
                }

                // Separadores mal agrupados: opción segura = quitar puntos.
                String digits = s.replace(".", "");
                if (digits.matches("\\d+")) {
                    return new Interpretation(Double.parseDouble(digits), null, false);
                }
            }

            // Múltiples comas o mezcla no válida. Quitamos separadores solo si
            // queda un número razonable; evitamos inventar decimales.
            String digits = s.replace(".", "").replace(",", "");
            if (digits.matches("\\d+")) {
                return new Interpretation(Double.parseDouble(digits), null, false);
            }
        } catch (NumberFormatException ignored) {
        }
        return null;
    }

    private static boolean validThousands(String integerPart) {
        if (integerPart == null || integerPart.isEmpty()) return false;
        String[] groups = integerPart.split("\\.", -1);
        if (groups.length == 1) return groups[0].matches("\\d+");
        if (!groups[0].matches("\\d{1,3}")) return false;
        for (int i = 1; i < groups.length; i++) {
            if (!groups[i].matches("\\d{3}")) return false;
        }
        return true;
    }

    private static Double distinct(double a, double b) {
        return Math.abs(a - b) < 0.0001 ? null : b;
    }

    private static int countChar(String s, char c) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == c) n++;
        return n;
    }

    static final class Interpretation {
        final double primary;
        final Double alternate;
        final boolean followsArgentineRules;

        Interpretation(double primary, Double alternate, boolean followsArgentineRules) {
            this.primary = primary;
            this.alternate = alternate;
            this.followsArgentineRules = followsArgentineRules;
        }
    }

    public static final class ParsedPrice {
        public final double valueArs;
        public final Double alternateValueArs;
        public final String rawText;
        public final String token;
        public final int score;
        public final boolean followsArgentineRules;

        ParsedPrice(double valueArs, Double alternateValueArs, String rawText, String token,
                    int score, boolean followsArgentineRules) {
            this.valueArs = valueArs;
            this.alternateValueArs = alternateValueArs;
            this.rawText = rawText;
            this.token = token;
            this.score = score;
            this.followsArgentineRules = followsArgentineRules;
        }
    }
}
