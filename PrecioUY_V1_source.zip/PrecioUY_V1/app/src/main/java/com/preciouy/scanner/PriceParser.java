package com.preciouy.scanner;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Lógica aislada para convertir texto OCR en un posible precio argentino. */
public final class PriceParser {
    private PriceParser() {}

    // Acepta 3.590 / 12.499,90 / 18500 / 1,299 / $ 8 990.
    private static final Pattern NUMBER = Pattern.compile(
            "(?<!\\d)([0-9]{1,3}(?:[.\\s][0-9]{3})+(?:,[0-9]{1,2})?|" +
            "[0-9]{1,3}(?:,[0-9]{3})+(?:\\.[0-9]{1,2})?|" +
            "[0-9]{1,7}(?:[.,][0-9]{1,2})?)(?!\\d)"
    );

    public static ParsedPrice parse(String raw) {
        if (raw == null) return null;
        String text = raw.trim();
        if (text.isEmpty()) return null;

        String lower = text.toLowerCase(Locale.ROOT);
        boolean hasCurrency = text.contains("$") || lower.contains("ars") || lower.contains("ar$");

        // Números que son casi seguro descuento, medida o cantidad y no precio.
        if (!hasCurrency) {
            if (text.contains("%") ||
                    lower.matches(".*\\b(kg|gr|g|mg|ml|cc|lts?|litros?|unid(?:ad)?es?)\\b.*")) {
                return null;
            }
        }

        Matcher matcher = NUMBER.matcher(text);
        ParsedPrice best = null;
        while (matcher.find()) {
            String token = matcher.group(1);
            Double value = normalizeNumber(token);
            if (value == null || value <= 0 || value > 9_999_999) continue;

            // Evita confundir códigos largos sin símbolo monetario.
            String digitsOnly = token.replaceAll("\\D", "");
            if (!hasCurrency && digitsOnly.length() >= 8) continue;

            int score = 0;
            if (hasCurrency) score += 100;
            if (token.contains(".") || token.contains(",") || token.contains(" ")) score += 10;
            if (value >= 100) score += 5;

            ParsedPrice candidate = new ParsedPrice(value, raw, score);
            if (best == null || candidate.score > best.score) best = candidate;
        }
        return best;
    }

    static Double normalizeNumber(String token) {
        if (token == null) return null;
        String s = token.replace(" ", "").trim();
        if (s.isEmpty()) return null;

        try {
            int lastDot = s.lastIndexOf('.');
            int lastComma = s.lastIndexOf(',');

            if (lastDot >= 0 && lastComma >= 0) {
                // En formato AR habitual: 12.499,90. Si el último separador
                // deja 1-2 dígitos lo tratamos como decimal.
                int lastSep = Math.max(lastDot, lastComma);
                char decimalSep = s.charAt(lastSep);
                int tail = s.length() - lastSep - 1;
                if (tail == 1 || tail == 2) {
                    char thousandsSep = decimalSep == ',' ? '.' : ',';
                    s = s.replace(String.valueOf(thousandsSep), "");
                    s = s.replace(decimalSep, '.');
                } else {
                    s = s.replace(".", "").replace(",", "");
                }
                return Double.parseDouble(s);
            }

            char sep = lastComma >= 0 ? ',' : (lastDot >= 0 ? '.' : '\0');
            if (sep != '\0') {
                int pos = s.lastIndexOf(sep);
                int tail = s.length() - pos - 1;
                int count = countChar(s, sep);

                if (count > 1) {
                    // 1.234.567 o 1,234,567: separadores de miles.
                    s = s.replace(String.valueOf(sep), "");
                } else if (tail == 3) {
                    // 3.590 / 12,499: miles.
                    s = s.replace(String.valueOf(sep), "");
                } else if (tail == 1 || tail == 2) {
                    // 3590,50 / 3590.5: decimal.
                    s = s.replace(sep, '.');
                } else {
                    s = s.replace(String.valueOf(sep), "");
                }
            }

            return Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static int countChar(String s, char c) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == c) n++;
        return n;
    }

    public static final class ParsedPrice {
        public final double valueArs;
        public final String rawText;
        public final int score;

        ParsedPrice(double valueArs, String rawText, int score) {
            this.valueArs = valueArs;
            this.rawText = rawText;
            this.score = score;
        }
    }
}
