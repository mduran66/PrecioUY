package com.preciouy.scanner;

import org.junit.Test;

import static org.junit.Assert.*;

public class PriceParserTest {

    @Test public void argentinaThousandsDot() {
        assertEquals(3590.0, PriceParser.parse("$ 3.590").valueArs, 0.001);
    }

    @Test public void argentinaThousandsAndDecimals() {
        assertEquals(12499.90, PriceParser.parse("ARS 12.499,90").valueArs, 0.001);
    }

    @Test public void integerPrice() {
        assertEquals(18500.0, PriceParser.parse("$18500").valueArs, 0.001);
    }

    @Test public void commaThousands() {
        assertEquals(1299.0, PriceParser.parse("$ 1,299").valueArs, 0.001);
    }

    @Test public void ignoresDiscountWithoutCurrency() {
        assertNull(PriceParser.parse("30% OFF"));
    }

    @Test public void ignoresWeightWithoutCurrency() {
        assertNull(PriceParser.parse("500 g"));
    }

    @Test public void pricePerKgWithCurrencyStillWorks() {
        assertEquals(14998.0, PriceParser.parse("Precio por kg $14.998").valueArs, 0.001);
    }
}
