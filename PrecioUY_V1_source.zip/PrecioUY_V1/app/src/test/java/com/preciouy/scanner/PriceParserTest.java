package com.preciouy.scanner;

import org.junit.Test;

import static org.junit.Assert.*;

public class PriceParserTest {
    @Test public void parsesArgentineThousands() {
        assertEquals(3590.0, PriceParser.parse("$ 3.590").valueArs, 0.001);
        assertEquals(12500.0, PriceParser.parse("12.500").valueArs, 0.001);
        assertEquals(1234567.0, PriceParser.parse("$ 1.234.567").valueArs, 0.001);
    }

    @Test public void parsesArgentineCents() {
        assertEquals(12499.90, PriceParser.parse("$ 12.499,90").valueArs, 0.001);
        assertEquals(12.50, PriceParser.parse("$ 12,50").valueArs, 0.001);
        assertNull(PriceParser.parse("$ 12,50").alternateValueArs);
    }

    @Test public void dotWithTwoDigitsBecomesAmbiguous() {
        PriceParser.ParsedPrice p = PriceParser.parse("$ 12.50");
        assertNotNull(p);
        assertEquals(12.50, p.valueArs, 0.001);
        assertNotNull(p.alternateValueArs);
        assertEquals(1250.0, p.alternateValueArs, 0.001);
    }

    @Test public void commaWithThreeDigitsIsAssumedThousandsOcrConfusion() {
        PriceParser.ParsedPrice p = PriceParser.parse("$ 12,500");
        assertNotNull(p);
        assertEquals(12500.0, p.valueArs, 0.001);
    }

    @Test public void ignoresUnitsAndDiscountsWithoutCurrency() {
        assertNull(PriceParser.parse("20% OFF"));
        assertNull(PriceParser.parse("500 g"));
    }
}
