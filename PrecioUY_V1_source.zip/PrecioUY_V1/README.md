# Precio UY — V0.2.0

Scanner Android de precios argentinos con conversión rápida a pesos uruguayos.

## V0.2
- Cámara + OCR en vivo.
- Área de escaneo movida algo hacia arriba.
- Área configurable por el usuario: ancho y alto entre 40% y 100% del tamaño máximo.
- Parser prioriza convención argentina: punto = miles; coma = centavos; grupos de miles de 3 cifras y centavos de 2.
- Si OCR rompe esas reglas y existe una interpretación útil alternativa, tocar el valor 🇦🇷 alterna entre ambas. Ej.: `12.50` → `12,50` ↔ `1.250`.
- El marco se pone verde cuando el precio queda confirmado.
- Etiquetas visuales 🇦🇷 ARS y 🇺🇾 UYU.
- Botón principal `🛒 AGREGAR`.
- `↶` deshace solamente la última inclusión y una sola vez.
- `Vaciar carrito` borra toda la compra con confirmación.
- Carrito, tipo de cambio y tamaño del área persisten localmente.
- Quick Settings tile y apertura sobre pantalla bloqueada, sujeto a restricciones del fabricante.

La cotización ARS→UYU sigue siendo manual en esta versión.


## V0.2.1
- Estabilización fuerte del OCR: no muestra lecturas provisionales/parciales.
- Histéresis al cambiar de precio y tolerancia a frames borrosos.
- Botones inferiores elevados respecto de la barra de navegación y con recuadro.
- Firma debug persistente incluida para permitir actualizar futuras builds de prueba.
