# Precio UY — V1 (0.1.0)

Scanner Android para apuntar a un precio expresado en ARS y verlo convertido a UYU sin sacar una foto.

## Qué hace esta V1

- Abre directamente en cámara.
- OCR continuo on-device con ML Kit (modelo latino empaquetado, no depende de Internet en uso).
- Prioriza precios cerca del centro y exige dos lecturas consecutivas antes de habilitar **Agregar**.
- Convierte ARS → UYU con un tipo de cambio manual configurable.
- Guarda la compra actual localmente: cantidad y total sobreviven cierre/bloqueo/reinicio de la app.
- **Deshacer** elimina el último precio.
- Pulsación larga sobre el total → iniciar una nueva compra.
- Se puede mostrar sobre el lockscreen mediante `showWhenLocked` / `turnScreenOn`.
- Incluye **Quick Settings Tile** “Precio UY”. En Android 13+ la app pide al sistema agregarla en el primer uso.
- Registra intents de cámara normal y cámara segura como experimento para accesos de sistema.

## Tipo de cambio inicial

V1 arranca en **1 ARS = 0,0267 UYU**. Es solo un valor inicial guardado en la app y puede cambiarse tocando el engranaje. La V1 **no actualiza automáticamente** la cotización.

## Redmi 12: expectativa real del doble clic

En Redmi/Xiaomi, el sistema ofrece normalmente **doble Power → Launch camera** y **doble Volumen abajo con pantalla bloqueada → Launch camera**. Esa preferencia es de Xiaomi y suele estar pensada para su aplicación de cámara; una app normal no puede interceptar directamente el botón Power.

La V1 hace el máximo razonable sin Accessibility ni hacks:

1. `MainActivity` puede mostrarse sobre el bloqueo.
2. Se registra como manejador de `STILL_IMAGE_CAMERA` y `STILL_IMAGE_CAMERA_SECURE`.
3. Si la ROM de ese Redmi entrega el intent de cámara a apps de terceros, Precio UY podrá aparecer/abrir.
4. Si HyperOS/MIUI lanza su cámara OEM directamente, **el doble Power no podrá redirigirse a Precio UY desde una app normal**. La baldosa queda como backup robusto.

## Primera prueba en el teléfono

1. Instalar la app.
2. Abrirla **una vez con el teléfono desbloqueado**.
3. Conceder **Cámara → Permitir mientras se usa la app**.
4. Aceptar el pedido del sistema para agregar la baldosa “Precio UY”. Si no aparece: abrir Centro de control → Editar → agregar “Precio UY”.
5. Apuntar a una etiqueta `$ 3.590`; mantenerla dentro del marco hasta que aparezca `Precio detectado ✓`.
6. Tocar **+ AGREGAR** y comprobar el total.
7. Bloquear el teléfono.
8. Desde bloqueado, bajar el Centro de control y tocar **Precio UY**. Debe abrir el scanner sin pedir patrón; el patrón sigue protegiendo el resto del teléfono.
9. Para probar doble clic: Ajustes → Ajustes adicionales → Accesos directos por gestos → Iniciar cámara → activar doble pulsación del botón de encendido. Bloquear y probar. Si abre la cámara Xiaomi directamente, es una restricción del launcher/ROM, no del OCR.

## Compilar en Android Studio

El proyecto usa:

- Java 17
- Android Gradle Plugin 8.13.2
- compileSdk / targetSdk 36
- minSdk 26
- CameraX 1.6.1
- ML Kit Text Recognition 16.0.1 (bundled)

Abrir la carpeta `PrecioUY_V1` con Android Studio. Al primer Sync, Android Studio descargará Gradle/dependencias si hacen falta. Luego:

**Build → Build App Bundle(s) / APK(s) → Build APK(s)**

El APK debug queda normalmente en:

`app/build/outputs/apk/debug/app-debug.apk`

## Qué observar para la siguiente iteración

Anotar especialmente:

- ¿La baldosa abre sobre el patrón o Xiaomi obliga a desbloquear?
- ¿El doble Power abre siempre la cámara Xiaomi o ofrece Precio UY?
- ¿Cuánto demora desde tocar el acceso hasta ver cámara?
- ¿Lee bien `$ 3.590`, `$3590`, `$ 12.499,90`?
- ¿Confunde pesos/gramos/descuentos con precios?
- ¿El marco central es demasiado grande/chico?
- ¿Hay etiquetas para las que haría falta zoom o tocar para enfocar?

